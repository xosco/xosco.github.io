#NoEnv
SetBatchLines, -1
SetMouseDelay, -1
CoordMode, Pixel, Screen
CoordMode, Mouse, Screen

BodyColor := 0xbf752f            ; Target color in BGR
Tolerance := 70
DebounceInterval := 150          ; ms
StabilizationLoops := 4

IsRed := false
LastClickTime := DllCall("GetTickCount64")
RedStreak := 0
NonRedStreak := 0

Loop
{
    if GetKeyState("E", "P")
    {
        MouseGetPos, MouseX, MouseY
        PixelGetColor, CurrentColor, MouseX, MouseY, RGB

        ; Calculate component-wise differences
        BlueDiff  := Abs((CurrentColor & 0xFF) - (BodyColor & 0xFF))
        GreenDiff := Abs(((CurrentColor >> 8) & 0xFF) - ((BodyColor >> 8) & 0xFF))
        RedDiff   := Abs(((CurrentColor >> 16) & 0xFF) - ((BodyColor >> 16) & 0xFF))

        IsCurrentlyRed := (RedDiff <= Tolerance && GreenDiff <= Tolerance && BlueDiff <= Tolerance)

        if IsCurrentlyRed
        {
            RedStreak++
            NonRedStreak := 0
        }
        else
        {
            NonRedStreak++
            RedStreak := 0
        }

        if (RedStreak >= StabilizationLoops && !IsRed)
        {
            CurrentTime := DllCall("GetTickCount64")
            if (CurrentTime - LastClickTime > DebounceInterval)
            {
                Click
                LastClickTime := CurrentTime
                IsRed := true
            }
        }

        if (NonRedStreak >= StabilizationLoops)
            IsRed := false
    }
    else
    {
        IsRed := false
        RedStreak := 0
        NonRedStreak := 0
    }

    Sleep, 1 ; Yield CPU slightly without compromising speed
}
